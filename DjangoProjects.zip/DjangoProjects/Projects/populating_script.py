import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE','first_project.settings')

import django
django.setup()

import random
from Appone.models import Access,webpage,Topic,User
from faker import Faker
fakegen=Faker()


'''fake_date=fakegen.date()
fake_name=fakegen.company()
fake_url=fakegen.url()

def add_topic():
    topics=['Family']
    t=Topic.objects.get_or_create(topic_name=random.choice(topics))
    #print(t)
    k=t[0]
    k.save
    return k

def populate(N=5):
    for entry in range(N):
        topic=add_topic()
        web=webpage.objects.get_or_create(topic=topic,webpage_name=fake_name,url=fake_url)[0]
        acces=Access.objects.get_or_create(name=web,date_accessed=fake_date)[0]
'''
def populate_users(N=5):
    for i in range(N):
        fake_fname=fakegen.first_name()
        fake_lname=fakegen.last_name()
        fake_email=fakegen.free_email()
        user=User.objects.get_or_create(fname=fake_fname,lname=fake_lname,email=fake_email)[0]


if __name__ == '__main__':
    print('Polpulating script')
    #populate(6)
    populate_users(6)
    print('Populating completed')
