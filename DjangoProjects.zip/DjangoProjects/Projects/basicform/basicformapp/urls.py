from django.conf.urls import url
from basicformapp import views

urlpatterns=[
    url('form',views.form_view,name='FormView'),
    url('submit',views.form_view,name='FormView'),

]
