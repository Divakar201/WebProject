from django.shortcuts import render
from . import forms
from .forms import FormView
# Create your views here.
def index(request):
    return render(request,'basicformapp/index.html')
def form_view(request):
    form_vie=forms.FormView()
    if request.method == 'POST':
        form=forms.FormView(request.POST)
        if form.is_valid():
            print("Validation sucessful")
            print('Name: '+form.cleaned_data['name'])

    return render(request,'basicformapp/form.html',{'form':form_vie})
