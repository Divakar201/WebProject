from django.apps import AppConfig


class BasicformappConfig(AppConfig):
    name = 'basicformapp'
