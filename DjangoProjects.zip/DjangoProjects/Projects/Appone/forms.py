from django import forms
from Appone.models import User

class NewUserForm(forms.ModelForm):
    class Meta():
        model = User
        fields="__all__"
