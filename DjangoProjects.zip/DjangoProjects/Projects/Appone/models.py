from django.db import models

# Create your models here.
class Topic(models.Model):
    topic_name = models.CharField(max_length=264,unique=True)
    def __str__(self):
        return self.topic_name
class webpage(models.Model):
    topic= models.ForeignKey(Topic,on_delete=models.DO_NOTHING)
    webpage_name = models.CharField(max_length=264,unique=True)
    url=models.URLField(unique=True)
    def __str__(self):
        return self.webpage_name
class Access(models.Model):
    name= models.ForeignKey(webpage,on_delete=models.DO_NOTHING)
    date_accessed= models.DateField()
    def __str__(self):
        return str(self.date_accessed)
class User(models.Model):
    fname=models.CharField(max_length=20)
    lname=models.CharField(max_length=20)
    email=models.CharField(max_length=50,unique=True)
    def __str__(self):
        return str(self.fname+" "+self.lname)
