from django.conf.urls import url
from Appone import views

urlpatterns=[
url('Help',views.Help,name='Help'),
url(r'^$',views.index,name='index'),
]
