from django.shortcuts import render
from django.http import HttpResponse
from Appone.models import Topic,Access,webpage,User
from Appone.forms import NewUserForm
import operator

# Create your views here.
def index(request):
    webpage_list=Access.objects.order_by('date_accessed')
    date_dict={'access_recrd':webpage_list}
    return render(request,'Appone/image.html',context=date_dict)

def Homepage(request):
    welcome_note={'insert':'Good to see you'}
    return render(request,'Appone/homepage.html',context=welcome_note)

def Help(request):
    my_dict={'insert':'Enjoy the View'}
    return render(request,'Appone/help.html',context=my_dict)
'''def Users(request):
    #list=User.objects.order_by('fname')
    users=User.objects.order_by('fname')
    #users=sorted(list,key=operator.attrgetter('fname'))
    my_users={'user_list':users}
    return render(request,'Appone/User.html',context=my_users)'''
def Users(request):
    form=NewUserForm()
    if request.method=='POST':
        form=NewUserForm(request.POST)
        if form.is_valid():
            form.save(commit=True)
            return index(request)
        else:
            print('ERROR FORM INVALID')
    return render(request,'Appone/User.html',{'form':form})
