from django.contrib import admin
from Appone.models import Access,Topic,webpage,User
# Register your models here.
admin.site.register(Access)
admin.site.register(Topic)
admin.site.register(webpage)
admin.site.register(User)
